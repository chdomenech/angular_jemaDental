export interface SeguroInteface {
  id?: string;
  nombre?: string;
  telefono?: string;
  direccion?:string;
  email?:string;
  especialidades?:any;
  sitioweb?:any;
}
