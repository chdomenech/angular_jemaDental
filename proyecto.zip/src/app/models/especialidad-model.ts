
export interface EspecialidadInterface {
  id?: string;
  nombre?: string;
}
