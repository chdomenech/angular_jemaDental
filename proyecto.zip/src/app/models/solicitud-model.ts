export interface SolicitudInterface {
  id?: string;
  cedulaSolicitante?: string;
  descripcion?: string;
  emailSolicitante?: string;
  estadoSolicitud?: string;
  fechaSolicitud?: number;
  nombreSolicitante?: string;  
  tipoSolicitud?: string;  
  respuesta?: string;
  estado?: string;

}
