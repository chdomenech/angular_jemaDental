export interface SeguroInteface {
  id?: string;
  nombre?: string;
}
