export interface TratamientoMInterface {

    id?: string;
    fecha?: any;
    cipaciente?: any;
    namepaciente?: string;
    seguro?: string;
    tratamiento?: string;
    especialidad?: string;
    odontologo?: any;
    nameodontologo?: any;
    observacion?: string;
    precio?: any;
}

  