import { PaginatorEspañol } from './paginator-español';

describe('PaginatorEspañol', () => {
  it('should create an instance', () => {
    expect(new PaginatorEspañol()).toBeTruthy();
  });
});
