export interface CitaMInterface {
  id?: string;
  fecha?: any;
  hora?: string;
  cipaciente?: any;
  namepaciente?: string;
  odontologo?: any;
  nameodontologo?: any;
  especialidad?: string;
  seguro?: string;
  estado?: string;
}
