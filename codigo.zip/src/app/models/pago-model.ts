export interface PagosInterface {
  id?: string;
  /*cedulaPaciente?: string;
  nombrePaciente?: string;*/
  fechaPago?: any;
  valorPago?: number;
  //asuntoPago?: string;
}
