export interface SolicitudInterface {
  id?: string;
  nombreSolicitante?: string;
  emailSolicitante?: string;
  fechaSolicitud?: number;
  descripcion?: string;
  tipoSolicitud?: string;
  EstadoSolicitud?: string;
}
