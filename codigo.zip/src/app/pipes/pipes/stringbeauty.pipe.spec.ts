import { StringbeautyPipe } from './stringbeauty.pipe';

describe('StringbeautyPipe', () => {
  it('create an instance', () => {
    const pipe = new StringbeautyPipe();
    expect(pipe).toBeTruthy();
  });
});
